# Déploiement sur Raspberry Pi 3B+ avec Nginx

## Prérequis

### Sur votre machine de développement :
- Node.js et npm installés
- Application React construite (`npm run build`)

### Sur votre Raspberry Pi :
- Raspberry Pi OS installé
- Connexion SSH activée
- Accès en ligne de commande (terminal ou SSH)

## Instructions de déploiement

### 1. Préparation des fichiers

Sur votre machine de développement :

```bash
# Construire l'application (déjà fait)
npm run build

# Créer une archive des fichiers de déploiement
tar -czf portfolio3d-deploy.tar.gz dist/ nginx.conf deploy.sh
```

### 2. Transfert vers la Raspberry Pi

```bash
# Copier l'archive sur votre Raspberry Pi
scp portfolio3d-deploy.tar.gz pi@[IP_DE_VOTRE_RASPBERRY_PI]:/home/pi/

# Se connecter à votre Raspberry Pi
ssh pi@[IP_DE_VOTRE_RASPBERRY_PI]
```

### 3. Installation sur la Raspberry Pi

Une fois connecté à votre Raspberry Pi :

```bash
# Extraire l'archive
tar -xzf portfolio3d-deploy.tar.gz

# Installer Nginx si ce n'est pas déjà fait
sudo apt update
sudo apt install nginx -y

# Rendre le script de déploiement exécutable
chmod +x deploy.sh

# Exécuter le script de déploiement
sudo ./deploy.sh
```

### 4. Vérification

Le script va :
- Créer le répertoire `/var/www/portfolio3d`
- Copier vos fichiers
- Configurer Nginx
- Redémarrer le serveur web

Votre application sera accessible à l'adresse : `http://[IP_DE_VOTRE_RASPBERRY_PI]`

## Configuration manuelle (alternative)

Si vous préférez configurer manuellement :

### 1. Créer le répertoire web
```bash
sudo mkdir -p /var/www/portfolio3d
sudo cp -r dist/* /var/www/portfolio3d/
sudo chown -R www-data:www-data /var/www/portfolio3d
sudo chmod -R 755 /var/www/portfolio3d
```

### 2. Configurer Nginx
```bash
sudo cp nginx.conf /etc/nginx/sites-available/portfolio3d
sudo ln -s /etc/nginx/sites-available/portfolio3d /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default
```

### 3. Redémarrer Nginx
```bash
sudo nginx -t
sudo systemctl restart nginx
sudo systemctl enable nginx
```

## Gestion du service

```bash
# Vérifier le statut de Nginx
sudo systemctl status nginx

# Redémarrer Nginx
sudo systemctl restart nginx

# Voir les logs
sudo tail -f /var/log/nginx/error.log
sudo tail -f /var/log/nginx/access.log
```

## Mise à jour de l'application

Pour mettre à jour votre application :

1. Reconstruire sur votre machine de développement
2. Recréer l'archive avec les nouveaux fichiers
3. Transférer et extraire sur la Raspberry Pi
4. Exécuter le script de déploiement

## Dépannage

### L'application ne se charge pas
- Vérifiez que Nginx fonctionne : `sudo systemctl status nginx`
- Vérifiez les logs : `sudo tail -f /var/log/nginx/error.log`
- Vérifiez la configuration : `sudo nginx -t`

### Erreur de permissions
```bash
sudo chown -R www-data:www-data /var/www/portfolio3d
sudo chmod -R 755 /var/www/portfolio3d
```

### Port déjà utilisé
Si le port 80 est occupé, modifiez le port dans `nginx.conf` :
```nginx
listen 8080;  # ou un autre port disponible
```
