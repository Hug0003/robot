#!/bin/bash

# Script de déploiement pour Raspberry Pi
echo "🚀 Déploiement de l'application sur Raspberry Pi..."

# Variables
APP_NAME="portfolio3d"
WEB_DIR="/var/www/$APP_NAME"
NGINX_SITES="/etc/nginx/sites-available"
NGINX_ENABLED="/etc/nginx/sites-enabled"

# Vérifier si on est root
if [ "$EUID" -ne 0 ]; then
    echo "❌ Veuillez exécuter ce script en tant que root (sudo)"
    exit 1
fi

# Créer le répertoire web
echo "📁 Création du répertoire web..."
mkdir -p $WEB_DIR

# Copier les fichiers du build
echo "📋 Copie des fichiers..."
cp -r dist/* $WEB_DIR/

# Donner les bonnes permissions
echo "🔐 Configuration des permissions..."
chown -R www-data:www-data $WEB_DIR
chmod -R 755 $WEB_DIR

# Copier la configuration Nginx
echo "⚙️ Configuration de Nginx..."
cp nginx.conf $NGINX_SITES/$APP_NAME

# Créer le lien symbolique
echo "🔗 Activation du site..."
ln -sf $NGINX_SITES/$APP_NAME $NGINX_ENABLED/

# Supprimer la configuration par défaut si elle existe
if [ -f "$NGINX_ENABLED/default" ]; then
    rm $NGINX_ENABLED/default
fi

# Tester la configuration Nginx
echo "🧪 Test de la configuration Nginx..."
nginx -t

if [ $? -eq 0 ]; then
    echo "✅ Configuration Nginx valide"
    # Redémarrer Nginx
    systemctl restart nginx
    systemctl enable nginx
    echo "🔄 Nginx redémarré"
    
    # Afficher l'IP de la Raspberry Pi
    IP=$(hostname -I | awk '{print $1}')
    echo "🎉 Déploiement terminé !"
    echo "📱 Votre application est accessible à l'adresse : http://$IP"
else
    echo "❌ Erreur dans la configuration Nginx"
    exit 1
fi
